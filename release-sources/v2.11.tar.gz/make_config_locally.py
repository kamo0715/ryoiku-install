#!/usr/bin/env python3
"""Offline: create secure .env for new Lolipop deployment, print one-time setup token."""
import base64,os,secrets,sys
from pathlib import Path
path=Path(__file__).resolve().parent/'upload_to_domain_root'/'_private'/'app'/'.env'
if path.exists():
    print('既存の .env があるため変更しません。移行時は既存の暗号化キーを引き継いでください。')
    sys.exit(1)
secret=secrets.token_urlsafe(48)
key=base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('ascii')
token=secrets.token_urlsafe(48)
path.parent.mkdir(parents=True,exist_ok=True)
path.write_text('\n'.join([
'APP_SECRET='+secret,
'DATA_ENCRYPTION_KEY='+key,
'APP_COOKIE_SECURE=true',
'APP_SETUP_TOKEN='+token,
'LOLI_CGI_MODE=true',
'']) ,encoding='utf-8')
try:os.chmod(path,0o600)
except OSError:pass
print('設定を作成しました: upload_to_domain_root/_private/app/.env')
print('初期管理者登録トークン（ほかの人に送らないでください）:')
print(token)
print('HTTPSを有効にして、ドメインの /first-setup を開き、登録してください。')

"""活動計画から「1日の支援の流れ（職員・関係機関用）」を作る。\n\n単一カリキュラムから1日全体は推定しない。前後の予定は職員の明示入力のみ。\n"""
from __future__ import annotations
from datetime import date, datetime, timedelta
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape
import re
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from docx import Document
from docx.shared import Cm, Pt
from docx.oxml.ns import qn
import xlsxwriter

class FlowError(ValueError):
    pass

MAX_EXTRA=4
MAX_STEPS=60
MAX_TOTAL=720
MAX_FIELD_LEN=800


def parse_input(plan, form):
    """認識済みの活動手順から日程を組み立てる。入力が不正なら何も生成しない。"""
    start=str(form.get('start_time','')).strip()
    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',start):
        raise FlowError('開始時刻を24時間形式（例：14:00）で入力してください。')
    h,m=map(int,start.split(':'))
    event_date=str(form.get('event_date','')).strip()
    if event_date:
        try:date.fromisoformat(event_date)
        except ValueError:raise FlowError('実施日の形式を確認してください。')
    location=str(form.get('location','')).strip()[:MAX_FIELD_LEN]
    staff_notes=str(form.get('staff_notes','')).strip()[:3000]
    agency_notes=str(form.get('agency_notes','')).strip()[:3000]
    shared_title=str(form.get('shared_title','')).strip()[:160]
    audience=str(form.get('audience','staff')).strip()
    if audience not in ('staff','agency'):raise FlowError('出力先が正しくありません。')
    if audience=='agency' and str(form.get('share_review',''))!='yes':
        raise FlowError('関係機関用は、共有内容を確認するチェックが必要です。')
    def extra(position):
        rows=[]
        for i in range(MAX_EXTRA):
            prefix=f'{position}_{i}_'
            values={k:str(form.get(prefix+k,'')).strip() for k in ('phase','minutes','child_action','staff_support','handoff')}
            if not any(values.values()):continue
            if not values['phase'] or not values['minutes']:
                raise FlowError('追加する予定には「場面」と「所要時間」の入力が必要です。')
            if not values['minutes'].isdigit():raise FlowError('所要時間は1～180分の整数で入力してください。')
            minutes=int(values['minutes'])
            if not 1<=minutes<=180:raise FlowError('追加予定の所要時間は1～180分で入力してください。')
            if any(len(v)>MAX_FIELD_LEN for v in values.values()):raise FlowError('追加予定の文章が長すぎます。')
            rows.append(dict(source='職員入力',minutes=minutes,**{k:values[k] for k in ('phase','child_action','staff_support','handoff')}))
        return rows
    before=extra('before');after=extra('after')
    saved=plan.get('data',{}).get('steps',[])
    if not isinstance(saved,list) or not 1<=len(saved)<=MAX_STEPS:raise FlowError('活動手順がありません。元のカリキュラムを確認してください。')
    middle=[]
    for step in saved:
        if not isinstance(step,dict):raise FlowError('活動手順を読み取れませんでした。')
        minutes=step.get('minutes',0)
        if isinstance(minutes,bool) or not isinstance(minutes,int) or not 1<=minutes<=180:
            raise FlowError('元の活動計画に不正な所要時間があります。活動計画を修正してください。')
        middle.append(dict(source='カリキュラム',phase=str(step.get('phase',''))[:MAX_FIELD_LEN],
            minutes=minutes,child_action=str(step.get('child_action',''))[:MAX_FIELD_LEN],
            staff_support=str(step.get('staff_support',''))[:MAX_FIELD_LEN],
            handoff=str(step.get('evaluation',''))[:MAX_FIELD_LEN]))
    rows=before+middle+after
    total=sum(row['minutes'] for row in rows)
    if total>MAX_TOTAL:raise FlowError('合計時間が12時間を超えています。')
    current=datetime(2000,1,1,h,m)
    if current+timedelta(minutes=total)>datetime(2000,1,2,0,0):
        raise FlowError('終了時刻が翌日になっています。開始時刻と予定を確認してください。')
    for row in rows:
        end=current+timedelta(minutes=row['minutes'])
        row['clock']=f'{current:%H:%M}～{end:%H:%M}'
        current=end
    return dict(rows=rows, event_date=event_date, start_time=start, end_time=f'{current:%H:%M}',
        total_minutes=total,location=location,staff_notes=staff_notes,agency_notes=agency_notes,
        shared_title=shared_title,audience=audience)


def _text(s):return str(s or '—')

def _public_rows(flow):
    """職員用の観察内容を関係機関版の時は同一に持ち込まず、共有欄として空欄にする。"""
    result=[]
    for row in flow['rows']:
        result.append([row['clock'],row['phase'],row['child_action'],row['staff_support'],
                       row['handoff'] if flow['audience']=='staff' else ''])
    return result

def _meta(plan,child,flow):
    audience=flow['audience']; title=(plan['data'].get('title') or '活動計画') if audience=='staff' else (flow['shared_title'] or '活動支援の流れ')
    return [('区分','職員用（内部共有）' if audience=='staff' else '関係機関用（共有内容確認済）'),
            ('活動名',title),('対象利用者',child.get('data',{}).get('name','未設定') if audience=='staff' else '共有先で必要に応じて記入'),
            ('実施日',flow['event_date'] or '未記入'),('活動場所',flow['location'] or '未記入'),
            ('予定時間',flow['start_time']+'～'+flow['end_time']+'（合計'+str(flow['total_minutes'])+'分）'),
            ('元カリキュラム',f'計画 #{plan["id"]}・'+('確認済' if plan['status']=='approved' else '未承認・下書き'))]

def _register_font():
    font='HeiseiKakuGo-W5'
    candidates=[Path('/usr/share/fonts/opentype/ipaexfont-gothic/ipaexg.ttf'),
                Path('/usr/share/fonts/truetype/ipaexfont-gothic/ipaexg.ttf'),
                Path('/usr/share/fonts/opentype/ipafont-gothic/ipag.ttf')]
    jpfont=next((x for x in candidates if x.is_file()),None)
    if jpfont:
        if 'FlowJP' not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont('FlowJP',str(jpfont)))
        return 'FlowJP'
    pdfmetrics.registerFont(UnicodeCIDFont(font));return font


def make_flow_pdf(plan,child,flow):
    buf=BytesIO();font=_register_font()
    doc=SimpleDocTemplate(buf,pagesize=landscape(A4),rightMargin=26,leftMargin=26,topMargin=28,bottomMargin=29,
       title='1日の支援の流れ（職員・関係機関用）')
    normal=ParagraphStyle('flownormal',fontName=font,fontSize=8,leading=12,wordWrap='CJK')
    small=ParagraphStyle('flowsmall',parent=normal,fontSize=7,leading=10)
    header_style=ParagraphStyle('flowheader',parent=small,textColor=colors.white)
    head=ParagraphStyle('flowhead',parent=normal,fontSize=16,leading=21,textColor=colors.HexColor('#194963'),spaceAfter=9)
    def P(s,sty=normal):return Paragraph(escape(_text(s)).replace('\n','<br/>'),sty)
    parts=[P('1日の支援の流れ',head),P('職員・関係機関用 / 活動計画から作成した確認用シート',small),Spacer(1,7)]
    meta=_meta(plan,child,flow)
    for j in range(0,len(meta),2):
        pairs=meta[j:j+2];cells=[]
        for label,value in pairs:cells.extend((P(label,small),P(value,small)))
        if len(pairs)==1:cells.extend((P('',small),P('',small)))
        t=Table([cells],colWidths=[86,278,86,278]);t.setStyle(TableStyle([
            ('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(0,0),colors.HexColor('#EDF4F6')),
            ('BACKGROUND',(2,0),(2,0),colors.HexColor('#EDF4F6')),
            ('BOTTOMPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),
            ('LINEBELOW',(0,0),(-1,-1),0.4,colors.HexColor('#D7E2EA'))]));parts.append(t)
    parts.append(Spacer(1,12))
    headers=['時間','場面','こどもの活動','職員の支援・関わり','観察・申し送り' if flow['audience']=='staff' else '共有・連携事項（共有先で記入）']
    cells=[[P(h,header_style) for h in headers]]
    for row in _public_rows(flow):cells.append([P(v,small) for v in row])
    t=Table(cells,colWidths=[89,111,168,195,165],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#194963')),
                          ('TEXTCOLOR',(0,0),(-1,0),colors.white),
                          ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F3F8F9')]),
                          ('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#CFDFE4')),
                          ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),
                          ('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),
                          ('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    parts.append(t);parts.append(Spacer(1,12))
    if flow['audience']=='staff':
        supp=plan.get('_support') or {}
        p=plan.get('data',{});sd=supp.get('data') or {}
        details=[('支援のねらい', '\n'.join(str(x) for x in p.get('objectives',[])[:4])),
                 ('配慮事項', '\n'.join(str(x) for x in p.get('accommodations',[])[:6])),
                 ('安全管理', '\n'.join(str(x) for x in p.get('safety',[])[:6])),
                 ('職員メモ',flow['staff_notes'])]
        if sd.get('short_goal'):details.insert(1,('個別支援計画の短期目標',sd['short_goal']))
    else:details=[('連携・共有メモ',flow['agency_notes'])]
    for label,value in details:
        parts.append(P(label,normal));parts.append(P(value,small));parts.append(Spacer(1,4))
    parts.append(P('注：カリキュラムの手順を時系列に変換しています。記載のない送迎・登所・休憩等は自動で追加していません。実施前に職員が内容・時間・共有範囲を確認してください。',small))
    def footer(canvas,document):
        canvas.saveState();canvas.setFont(font,7.5);canvas.setFillColor(colors.HexColor('#64748b'))
        canvas.drawString(27,17,'支援の流れ（案）｜正式な個別支援計画を代替しません')
        canvas.drawRightString(landscape(A4)[0]-27,17,f'{document.page}ページ');canvas.restoreState()
    doc.build(parts,onFirstPage=footer,onLaterPages=footer)
    buf.seek(0);return buf


def make_flow_docx(plan,child,flow):
    buf=BytesIO();doc=Document();sec=doc.sections[0]
    sec.page_width=Cm(29.7);sec.page_height=Cm(21.0)
    sec.top_margin=sec.bottom_margin=Cm(1.35);sec.left_margin=sec.right_margin=Cm(1.4)
    style=doc.styles['Normal'];style.font.name='Yu Gothic';style.font.size=Pt(9)
    style._element.rPr.rFonts.set(qn('w:eastAsia'),'Yu Gothic')
    style.paragraph_format.space_after=Pt(2)
    doc.styles['Heading 2'].paragraph_format.space_before=Pt(8)
    doc.styles['Heading 2'].paragraph_format.space_after=Pt(2)
    doc.add_heading('1日の支援の流れ',0)
    doc.add_paragraph('職員・関係機関用｜内容確認後に使用する支援の流れ（案）／送迎・休憩等は職員が追加')
    for label,value in _meta(plan,child,flow):doc.add_paragraph(f'{label}：{value}')
    t=doc.add_table(rows=1,cols=5);t.style='Table Grid'
    heads=['時間','場面','こどもの活動','職員の支援・関わり','観察・申し送り' if flow['audience']=='staff' else '共有・連携事項（共有先で記入）']
    for c,v in zip(t.rows[0].cells,heads):c.text=v
    for row in _public_rows(flow):
        for c,v in zip(t.add_row().cells,row):c.text=_text(v)
    if flow['audience']=='staff':
        p=plan.get('data',{});sd=(plan.get('_support') or {}).get('data') or {}
        for label,content in [('支援のねらい','\n'.join(p.get('objectives',[]))),('個別支援計画の短期目標',sd.get('short_goal','')),
          ('配慮事項','\n'.join(p.get('accommodations',[]))),('安全管理','\n'.join(p.get('safety',[]))),('職員メモ',flow['staff_notes'])]:
            doc.add_heading(label,level=2);doc.add_paragraph(_text(content))
    else:
        doc.add_heading('連携・共有メモ',level=2);doc.add_paragraph(_text(flow['agency_notes']))
    sec.footer.paragraphs[0].text='支援の流れ（案）｜正式な個別支援計画を代替しません'
    doc.save(buf);buf.seek(0);return buf


def make_flow_xlsx(plan,child,flow):
    buf=BytesIO();wb=xlsxwriter.Workbook(buf,{'in_memory':True})
    h=wb.add_format({'bold':True,'bg_color':'#194963','font_color':'#FFFFFF','text_wrap':True,'valign':'top','border':1,'border_color':'#C9D8E0'})
    cell=wb.add_format({'text_wrap':True,'valign':'top','border':1,'border_color':'#C9D8E0'})
    label=wb.add_format({'bold':True,'bg_color':'#E9F2F4','text_wrap':True})
    title=wb.add_format({'bold':True,'font_size':16,'font_color':'#194963'})
    ws=wb.add_worksheet('1日の支援の流れ');ws.set_landscape();ws.fit_to_pages(1,0);ws.set_paper(9);ws.freeze_panes(11,0)
    ws.set_margins(.35,.35,.45,.45)
    for n,w in enumerate([15,20,36,43,33]):ws.set_column(n,n,w)
    ws.merge_range('A1:E2','1日の支援の流れ（'+('職員用' if flow['audience']=='staff' else '関係機関用')+'）',title)
    for ix,(k,v) in enumerate(_meta(plan,child,flow),3):
        ws.write_string(ix-1,0,k,label);ws.merge_range(ix-1,1,ix-1,4,str(v),cell)
    start=11
    headers=['時間','場面','こどもの活動','職員の支援・関わり','観察・申し送り' if flow['audience']=='staff' else '共有・連携事項（共有先で記入）']
    for j,v in enumerate(headers):ws.write_string(start,j,v,h)
    for rid,row in enumerate(_public_rows(flow),start+1):
        for j,v in enumerate(row):ws.write_string(rid,j,str(v or ''),cell)
        ws.set_row(rid,50)
    pos=start+len(flow['rows'])+3
    if flow['audience']=='staff':
        sd=(plan.get('_support') or {}).get('data') or {};p=plan.get('data',{})
        details=[('支援のねらい','\n'.join(p.get('objectives',[]))),('個別支援計画の短期目標',sd.get('short_goal','')),
                ('配慮事項','\n'.join(p.get('accommodations',[]))),('安全管理','\n'.join(p.get('safety',[]))),('職員メモ',flow['staff_notes'])]
    else:details=[('連携・共有メモ',flow['agency_notes'])]
    for k,v in details:
        ws.write_string(pos,0,k,label);ws.merge_range(pos,1,pos,4,str(v or ''),cell);ws.set_row(pos,42);pos+=1
    ws.merge_range(pos,0,pos,4,'注意：カリキュラム外の予定は職員が追加してください。正式な個別支援計画の代替ではありません。',cell)
    ws.set_footer('&L支援の流れ（案） / 職員確認用&R&P / &N');wb.close();buf.seek(0);return buf

"""Data minimization for external AI requests (v2.17).

Never forward a value from a child/support/free-text input to an AI provider.
Only enumerated, locally derived generic support categories and a public
curriculum catalog code may cross this trust boundary.

This is NOT a formal guarantee of 匿名加工情報 under Japanese law.
"""
import json
import re
from catalog import OTHER_KINDS, KIND_GROUP, CATEGORY_FOCUS, CATEGORY_SAFETY, EXTRA_SAFETY

# Only fixed Japanese phrases from these tables are allowed as outbound strings.
GOAL_TAGS = (
    (r'選択|選ぶ|選べ|決める|自己決定', '活動や手順を自分で選ぶ'),
    (r'意思表示|伝え|気持ち|希望|表現|発信', '意思や希望を伝える'),
    (r'協力|順番|交代|役割|共同|友達|集団', '協同・順番・役割調整'),
    (r'見通し|段取り|予定|手順|切り替え', '見通しをもって活動する'),
    (r'援助要請|助け|相談|お願い|頼る', '援助や休憩を求める'),
    (r'集中|注意|継続|持続|最後まで', '活動への参加を継続する'),
    (r'休憩|疲労|疲れ|自己調整|落ち着', '休憩と自己調整'),
    (r'読字|読む|読み|書字|書く|文字|計算|数|学習|タイピング', '読み書き・数量の基礎活動'),
    (r'運動|姿勢|身体|感覚|手先|指先|動作', '身体の動きや感覚への配慮'),
    (r'生活|身支度|着替え|片付け|自立|準備', '生活や身の回りの活動'),
)
METHOD_TAGS = (
    (r'視覚|絵カード|図|写真|手順表|タイマー|スケジュール', '視覚的な手順提示'),
    (r'短い指示|短く伝|一つずつ|簡潔', '短い段階的な説明'),
    (r'選択肢|二択|2択|自由選択', '選択肢の提示'),
    (r'休憩|休む|退出|無理をさせない', '休憩・途中退出の選択'),
    (r'個別|少人数|ペースに合わせ', '本人のペースへの配慮'),
    (r'意思|表出|伝える|非言語|ジェスチャー', '多様な意思表出方法の尊重'),
)
DOMAIN_KEYS = (
    ('domain_health','健康・生活'),
    ('domain_motor','運動・感覚'),
    ('domain_cognition','認知・行動'),
    ('domain_language','言語・コミュニケーション'),
    ('domain_social','人間関係・社会性'),
)
ALLOW_TAGS={x[1] for x in GOAL_TAGS} | {x[1] for x in METHOD_TAGS}
ALLOW_DOMAINS={x[1] for x in DOMAIN_KEYS}
ACTIVITY_MODE_VALUES={'minecraft','other'}
CLASS_SIZE_VALUES={'個別活動','小集団活動','形態は現場で確認'}


def _fixed_tags(source, mapping):
    # Search only to select one of our FIXED labels. No match text is returned.
    return [fixed for pattern,fixed in mapping if re.search(pattern, source, flags=re.I)]


def build_minimal_payload(child, support, options):
    """Return only non-identifying, fixed-vocabulary AI task inputs.

    No child name, child codes, locations, dates, health facts, family story,
    diagnosis, school, goals verbatim, or free-text activity details.
    """
    if not isinstance(child,dict) or not isinstance(support,dict) or not isinstance(options,dict):
        raise ValueError('AI data mapping unavailable')
    mode=str(options.get('activity_mode',''))
    if mode not in ACTIVITY_MODE_VALUES:
        raise ValueError('Invalid activity mode')
    try:
        duration=int(options.get('duration'))
    except (TypeError,ValueError):
        raise ValueError('Invalid activity duration')
    if not (15<=duration<=180):
        raise ValueError('Invalid activity duration')
    kind_code='minecraft' if mode=='minecraft' else str(options.get('kind_code',''))
    if mode=='other' and kind_code not in OTHER_KINDS:
        raise ValueError('Invalid public catalog code')
    # Never send custom_activity text, even when kind_code == 'other'.
    label='Minecraft' if mode=='minecraft' else (OTHER_KINDS[kind_code] if kind_code!='other' else '自由活動（詳細は職員が確認）')
    group='デジタル創作・遊び' if mode=='minecraft' else KIND_GROUP[kind_code]
    focus='本人の意思・役割選択・協力を観察する' if mode=='minecraft' else CATEGORY_FOCUS[group]
    safe='既知でない相手とのオンライン接続を避ける' if mode=='minecraft' else (CATEGORY_SAFETY[group]+' '+EXTRA_SAFETY.get(kind_code,'')).strip()
    # The input may include very sensitive private facts. Only generic topics leave.
    relevant=' '.join(str(support.get(k,'') or '') for k in (
        'child_intentions','long_goal','short_goal','support_policy',
        'domain_health','domain_motor','domain_cognition','domain_language',
        'domain_social','accommodation','assessment'))
    # Not used: family_intentions, family_support, original_text, child profile.
    # Generic methods only; never copy raw text into the payload.
    goals=_fixed_tags(relevant,GOAL_TAGS)
    methods=_fixed_tags(relevant,METHOD_TAGS)
    domains=[label for key,label in DOMAIN_KEYS if str(support.get(key,'') or '').strip()]
    size=str(options.get('group_size','') or '')
    group_size='個別活動' if re.search('個別',size) else ('小集団活動' if re.search('集団|グループ|複数',size) else '形態は現場で確認')
    return {
        'request_type':'general_activity_draft',
        'privacy_version':'fixed-vocabulary-1',
        'profile':{'subject':'匿名の支援対象','age':'非送信','individual_attributes':'非送信'},
        'support_context':{
            'has_registered_plan':bool(support),
            'generic_objective_tags':goals,
            'generic_support_methods':methods,
            'relevant_domains':domains,
            'source_goals_verbatim':'非送信・職員がローカルで原文照合',
        },
        'activity':{
            'activity_mode':mode,
            'kind_code':kind_code,
            'catalog_label':label,
            'catalog_group':group,
            'catalog_focus':focus,
            'catalog_safety':safe,
            'duration_minutes':duration,
            'group_form':group_size,
            'free_text':'非送信・職員がローカルで確認',
        },
    }


def check_minimal_payload(payload):
    """Fail closed if the outgoing object has any extra fields or non-whitelisted strings."""
    if not isinstance(payload,dict) or set(payload)!={'request_type','privacy_version','profile','support_context','activity'}:
        raise ValueError('AI payload schema mismatch')
    if payload['request_type']!='general_activity_draft' or payload['privacy_version']!='fixed-vocabulary-1':
        raise ValueError('AI payload version mismatch')
    if payload['profile']!={'subject':'匿名の支援対象','age':'非送信','individual_attributes':'非送信'}:
        raise ValueError('Personal profile was included')
    sup=payload['support_context']
    if not isinstance(sup,dict) or set(sup)!={'has_registered_plan','generic_objective_tags','generic_support_methods','relevant_domains','source_goals_verbatim'}:
        raise ValueError('Support schema mismatch')
    if type(sup['has_registered_plan']) is not bool or sup['source_goals_verbatim']!='非送信・職員がローカルで原文照合':
        raise ValueError('Raw plan source forbidden')
    for key, allowed in [('generic_objective_tags',{v for _,v in GOAL_TAGS}),('generic_support_methods',{v for _,v in METHOD_TAGS}),('relevant_domains',ALLOW_DOMAINS)]:
        v=sup[key]
        if not isinstance(v,list) or len(v)>12 or any(type(x) is not str or x not in allowed for x in v):
            raise ValueError('Non-approved support topic blocked')
    act=payload['activity']
    if not isinstance(act,dict) or set(act)!={'activity_mode','kind_code','catalog_label','catalog_group','catalog_focus','catalog_safety','duration_minutes','group_form','free_text'}:
        raise ValueError('Activity schema mismatch')
    if type(act['duration_minutes']) is not int or not 15<=act['duration_minutes']<=180 or act['group_form'] not in CLASS_SIZE_VALUES or act['free_text']!='非送信・職員がローカルで確認':
        raise ValueError('Raw request blocked')
    # Reconstruct from fixed public catalog. No arbitrary labels allowed.
    original=build_minimal_payload({}, {}, {'activity_mode':act['activity_mode'], 'kind_code':act['kind_code'], 'duration':act['duration_minutes']})
    for key in ('activity_mode','kind_code','catalog_label','catalog_group','catalog_focus','catalog_safety'):
        if act[key]!=original['activity'][key]:
            raise ValueError('Unapproved activity text blocked')
    result=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
    if len(result)>16000:
        raise ValueError('Unexpected payload size')
    return result

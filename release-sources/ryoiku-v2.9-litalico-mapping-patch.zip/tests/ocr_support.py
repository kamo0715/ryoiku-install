"""v2.5 photo OCR -> preview -> human verification -> encrypted version, no photo persistence."""
from pathlib import Path
from io import BytesIO
from unittest.mock import patch
import os,re,tempfile,sys
from cryptography.fernet import Fernet
from PIL import Image
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from ocr_import import parse_support_text,OCRImportError,recognize_image,MAX_PHOTO_BYTES

raw='''児童氏名: 架空 花子
本人の希望：工作をやってみたい
保護者の意向：落ち着いて活動できるようになってほしい
長期目標：友達と協力して活動に参加する
短期目標：順番を待ってから自分の希望を伝える
健康・生活：活動前の手洗いを確認する
言語・コミュニケーション：選択肢から希望を伝える
合理的配慮：大きな音が苦手な時は静かな場所に移動する
適用開始日: 2026年11月1日
適用終了日: 2027年4月30日'''
fields, count, warnings, names=parse_support_text(raw)
assert count>=8,(count,fields)
assert fields['long_goal']=='友達と協力して活動に参加する'
assert fields['short_goal']=='順番を待ってから自分の希望を伝える'
assert fields['period_start']=='2026-11-01'
assert fields['period_end']=='2027-04-30'
assert names == ['架空 花子']
assert fields['original_text']==raw
assert 'long_goal' not in parse_support_text('長期目標が決まっていません')[0]
try:
    parse_support_text(' ')
    raise AssertionError('blank OCR must fail')
except OCRImportError:
    pass
im=Image.new('RGB',(100,60),'white'); buf=BytesIO(); im.save(buf,format='PNG'); image_bytes=buf.getvalue()

with tempfile.TemporaryDirectory(prefix='ryoiku_photo_test_') as tmp:
    os.environ['APP_SECRET']='q'*64
    os.environ['DATA_ENCRYPTION_KEY']=Fernet.generate_key().decode()
    os.environ['APP_DB_PATH']=str(Path(tmp)/'db.sqlite3')
    os.environ['APP_LOG_DIR']=str(Path(tmp)/'logs')
    from fastapi.testclient import TestClient
    from app import app
    from storage import create_user,support_history
    def csrf(page):
        m=re.search(r'name="_csrf" value="([^"]+)"',page.text)
        assert m
        return m.group(1)
    with TestClient(app) as client:
        create_user('example_admin','TestPassword12345!','admin')
        page=client.get('/login')
        assert client.post('/login',data={'_csrf':csrf(page),'username':'example_admin',
            'password':'TestPassword12345!'},follow_redirects=False).status_code==303
        page=client.get('/children/new')
        assert client.post('/children/new',data={'_csrf':csrf(page),
            'code':'DEMO-1','name':'架空 花子'},follow_redirects=False).status_code==303
        page=client.get('/children/1/support/new')
        assert '/children/1/support/ocr' in page.text
        before=support_history(1)
        with patch('app.recognize_image',return_value=raw):
            result=client.post('/children/1/support/ocr',data={'_csrf':csrf(page)},
                files={'photos':('sheet.png',image_bytes,'image/png')})
        assert result.status_code==200,result.text[:600]
        assert '読み取りが終わりました' in result.text
        assert '友達と協力して活動に参加する' in result.text
        assert support_history(1)==before  # photo reading MUST NOT create a plan
        m=re.search(r'name="ocr_preview_token" value="([^"]+)"',result.text)
        assert m
        pending=m.group(1)
        save_data={'_csrf':csrf(result),'ocr_preview_token':pending,
                   'original_text':raw,'long_goal':fields['long_goal'],
                   'short_goal':fields['short_goal']}
        not_yet=client.post('/children/1/support/new',data=save_data)
        assert not_yet.status_code==200 and 'もう一度読み取って' in not_yet.text
        assert support_history(1)==before
        save_data['ocr_verified']='yes'
        save_data.update({'review_child_intentions':'yes','review_family_intentions':'yes','review_assessment':'yes'})
        done=client.post('/children/1/support/new',data=save_data,follow_redirects=False)
        assert done.status_code==303
        assert len(support_history(1))==1
        stored=support_history(1)[0]
        assert stored['data']['short_goal']==fields['short_goal']
        # Source text must be encrypted; no image data, name, or OCR text in logs.
        db=Path(os.environ['APP_DB_PATH']).read_bytes()
        assert raw.encode() not in db
        for log in (Path(tmp)/'logs').glob('*.csv'):
            body=log.read_text(encoding='utf-8')
            assert '架空 花子' not in body and '友達と協力' not in body
        page=client.get('/children/1/support/new')
        result=client.post('/children/1/support/ocr',data={'_csrf':csrf(page)},
             files={'photos':('large.png',b'x'*(MAX_PHOTO_BYTES+1),'image/png')})
        assert '8MB以下' in result.text
print('PASS: OCR mapping, manual confirmation, CSRF, max upload, encrypted support version, safe audit logs')

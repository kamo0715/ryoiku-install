"""PDF text/OCR and authenticated preview tests, using fictional data and temporary DB."""
import os
import re
import sys
import tempfile
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

import fitz
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas
from cryptography.fernet import Fernet

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from ocr_import import OCRImportError
from pdf_import import extract_support_pdf, MAX_PDF_BYTES

PDF_TEXT = [
    '児童氏名：架空 花子',
    '長期目標：友達と協力して活動に参加する',
    '短期目標：順番を守って自分の希望を伝える',
    '本人の希望：工作をやってみたい',
    '保護者の意向：落ち着いて活動できるようになってほしい',
    '健康・生活：活動前の手洗いを確認する',
    '合理的配慮：必要に応じて静かな場所に移動する',
    '適用開始日：2026年11月1日',
    '適用終了日：2027年4月30日',
]


def make_text_pdf():
    mem=BytesIO()
    pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
    c=canvas.Canvas(mem,pagesize=(595,842))
    c.setFont('HeiseiKakuGo-W5',15)
    for index,line in enumerate(PDF_TEXT):
        c.drawString(45,790-index*55,line)
    c.save()
    return mem.getvalue()


def make_scan_pdf():
    image=Image.new('RGB',(1400,1900),'white')
    draw=ImageDraw.Draw(image)
    candidates=[
        '/usr/share/fonts/opentype/ipaexfont-gothic/ipaexg.ttf',
        '/usr/share/fonts/truetype/ipaexfont-gothic/ipaexg.ttf',
        '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    ]
    path=next((x for x in candidates if Path(x).exists()),None)
    assert path, 'No Japanese font for PDF scan test'
    font=ImageFont.truetype(path,38)
    for index,line in enumerate(PDF_TEXT[:6]):
        draw.text((75,100+index*180),line,fill='black',font=font)
    mem=BytesIO(); image.save(mem,format='PNG')
    doc=fitz.open()
    page=doc.new_page(width=595,height=842)
    page.insert_image(page.rect,stream=mem.getvalue())
    assert not page.get_text().strip()
    result=doc.tobytes()
    doc.close()
    return result


text_pdf=make_text_pdf()
extracted, scanned, warnings=extract_support_pdf(text_pdf)
assert scanned==0,(scanned,extracted[:200])
assert '長期目標：友達と協力して活動に参加する' in extracted,repr(extracted[:1000])
assert '適用開始日' in extracted

scan_pdf=make_scan_pdf()
ocr_text,scanned,warnings=extract_support_pdf(scan_pdf)
assert scanned==1,(scanned,ocr_text[:350],warnings)
assert '長期目標' in ocr_text,(ocr_text[:1500],warnings)
assert '短期目標' in ocr_text,(ocr_text[:1500],warnings)

# Mixed pages: must read both native text and OCR images without discarding pages.
mixed=fitz.open(stream=text_pdf,filetype='pdf')
scanned_doc=fitz.open(stream=scan_pdf,filetype='pdf')
mixed.insert_pdf(scanned_doc)
mixed_blob=mixed.tobytes()
mixed.close();scanned_doc.close()
extracted,scanned,_=extract_support_pdf(mixed_blob)
assert scanned==1 and extracted.count('長期目標')>=2,(scanned,extracted)

# Corrupt, non-PDF, password-protected, oversize, too many pages.
for data,expected in [(b'not a PDF','PDF_FORMAT'),(text_pdf+b'x'*(MAX_PDF_BYTES+1),'PDF_SIZE'),(b'%PDF-garbage','PDF_INVALID')]:
    try:
        extract_support_pdf(data)
        raise AssertionError(f'accepted bad PDF: {expected}')
    except OCRImportError as exc:
        assert exc.code==expected,(exc.code,expected)

many=fitz.open()
for _ in range(13):many.new_page()
try:
    extract_support_pdf(many.tobytes())
    raise AssertionError('accepted 13-page PDF')
except OCRImportError as exc:
    assert exc.code=='PDF_PAGES'
many.close()
protected=fitz.open(stream=text_pdf,filetype='pdf')
password_blob=protected.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256,owner_pw='test-owner',user_pw='test-user')
protected.close()
try:
    extract_support_pdf(password_blob)
    raise AssertionError('accepted password-protected PDF')
except OCRImportError as exc:
    assert exc.code=='PDF_PASSWORD'

with tempfile.TemporaryDirectory(prefix='ryoiku_pdf_test_') as temp:
    os.environ['APP_SECRET']='p'*64
    os.environ['DATA_ENCRYPTION_KEY']=Fernet.generate_key().decode()
    os.environ['APP_DB_PATH']=str(Path(temp)/'db.sqlite3')
    os.environ['APP_LOG_DIR']=str(Path(temp)/'logs')
    from fastapi.testclient import TestClient
    from app import app
    from storage import create_user,support_history
    def csrf(page):
        match=re.search(r'name="_csrf" value="([^"]+)"',page.text)
        assert match,page.text[:400]
        return match.group(1)
    with TestClient(app) as client:
        create_user('testadmin','DemoOnlyPassword123!','admin')
        assert client.get('/children/1/support/new',follow_redirects=False).status_code==303
        login=client.get('/login')
        assert client.post('/login',data={'_csrf':csrf(login),'username':'testadmin','password':'DemoOnlyPassword123!'},follow_redirects=False).status_code==303
        page=client.get('/children/new')
        assert client.post('/children/new',data={'_csrf':csrf(page),'code':'SAMPLE-1','name':'架空 花子'},follow_redirects=False).status_code==303
        page=client.get('/children/1/support/new')
        assert 'action="/children/1/support/pdf"' in page.text
        before=support_history(1)
        bad_csrf=client.post('/children/1/support/pdf',data={'_csrf':'wrong'},files={'pdf_file':('sample.pdf',text_pdf,'application/pdf')})
        assert bad_csrf.status_code==403
        preview=client.post('/children/1/support/pdf',data={'_csrf':csrf(page)},files={'pdf_file':('sample.pdf',text_pdf,'application/pdf')})
        assert preview.status_code==200,preview.text[:400]
        assert 'PDFの読み取りが終わりました' in preview.text
        assert '友達と協力して活動に参加する' in preview.text
        assert support_history(1)==before
        token=re.search(r'name="ocr_preview_token" value="([^"]+)"',preview.text).group(1)
        form={'_csrf':csrf(preview),'ocr_preview_token':token,'long_goal':'友達と協力して活動に参加する','short_goal':'順番を守って自分の希望を伝える','original_text':extracted}
        blocked=client.post('/children/1/support/new',data=form)
        assert blocked.status_code==200 and '読み取り結果を保存できません' in blocked.text
        assert support_history(1)==before
        form['ocr_verified']='yes'
        form.update({'review_child_intentions':'yes','review_family_intentions':'yes','review_assessment':'yes'})
        done=client.post('/children/1/support/new',data=form,follow_redirects=False)
        assert done.status_code==303,done.text[:400]
        assert len(support_history(1))==1
        db=Path(os.environ['APP_DB_PATH']).read_bytes()
        assert '友達と協力して活動に参加する'.encode() not in db
        for log in Path(temp,'logs').glob('*.csv'):
            body=log.read_text(encoding='utf-8')
            assert '架空 花子' not in body and '友達と協力' not in body
        page=client.get('/children/1/support/new')
        no_pdf=client.post('/children/1/support/pdf',data={'_csrf':csrf(page)},files={'pdf_file':('not.pdf',b'wrong','application/pdf')})
        assert 'PDF形式' in no_pdf.text
print('PASS: v2.6 native PDF, scanned OCR, mixed pages, safety limits, CSRF, preview, encryption, logging')
